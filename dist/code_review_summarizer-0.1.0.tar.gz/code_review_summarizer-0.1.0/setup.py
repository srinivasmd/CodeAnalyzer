from setuptools import setup, find_packages

setup(
    name="code-review-summarizer",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "gitpython",
        "openai",
        "python-dotenv"
    ],
    entry_points={
        "console_scripts": [
            "code-review-summarizer = code_review_summarizer.main:main"
        ]
    },
)